package workers

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"jsonproject/encdec"
	"jsonproject/model"
	"os"
	"sync"
)

func SpawnWorkers(wNum int, taskCh chan model.InputData, wg *sync.WaitGroup) {
	for i := 0; i < wNum; i++ {
		wg.Add(1)
		go worker(taskCh, wg)
	}
}

func AssignTask(ipDatas []model.InputData, taskCh chan model.InputData) {
	defer close(taskCh)

	for _, ipData := range ipDatas {
		taskCh <- ipData
	}
}

func worker(taskCh chan model.InputData, wg *sync.WaitGroup) {
	defer wg.Done()

	for ipdata := range taskCh {

		hash := sha256.New()
		hash.Write([]byte(ipdata.Content))
		hashRes := hash.Sum(nil)
		hashString := hex.EncodeToString(hashRes)

		op := model.OpData{
			Content: ipdata.Content,
			Hash:    hashString,
		}

		opByte, err := json.Marshal(op)

		if err != nil {
			fmt.Println("err", err)
		}

		encStr := encdec.Encrypt(string(opByte)) //yes
		os.WriteFile("op/"+ipdata.FileName, []byte(encStr),
			os.FileMode(os.O_WRONLY))
	}
}

package encdec

func Encrypt(str string) string {
	var result string

	for _, v := range str {
		result += string(v + 1)
	}

	return result
}

func Decrypt(str string) string {
	var result string
	for _, v := range str {
		result += string(v - 1)
	}

	return result
}

package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"jsonproject/encdec"
	"jsonproject/model"
	"os"
)

const INPUT_FILE_NAME = "input.json"

func main() {
	// var wg sync.WaitGroup

	// ipDatas := ReadInputJSONtoStruct()
	// taskCh := make(chan model.InputData, len(ipDatas))

	// workers.SpawnWorkers(10, taskCh, &wg)
	// workers.AssignTask(ipDatas, taskCh)

	// wg.Wait()

	encString := ReadEncryptedFile("f2.txt")

	orgStr := encdec.Decrypt(encString) //or

	op := model.OpData{}
	json.Unmarshal([]byte(orgStr), &op)
	if ValidateData(op) {
		fmt.Println("--------", op.Content)
		return
	}
	fmt.Println("Tampered!!!")

}

func ValidateData(op model.OpData) bool {

	hash := sha256.New()
	hash.Write([]byte(op.Content))
	hashRes := hash.Sum(nil)
	hashString := hex.EncodeToString(hashRes)

	if hashString != op.Hash {
		return false
	}

	return true

}

func ReadInputJSONtoStruct() []model.InputData {
	ipDatas := []model.InputData{}

	fileByte, err := os.ReadFile(INPUT_FILE_NAME)
	if err != nil {
		fmt.Println(err)
	}

	err = json.Unmarshal(fileByte, &ipDatas)
	if err != nil {
		fmt.Println(err)
	}

	return ipDatas
}

func ReadEncryptedFile(fileName string) string {
	fileByte, err := os.ReadFile("op/" + fileName)
	if err != nil {
		fmt.Println(err)
	}

	return string(fileByte)
}

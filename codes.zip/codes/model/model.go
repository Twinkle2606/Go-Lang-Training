package model

type InputData struct {
	FileName string
	Content  string
}

type OpData struct {
	Hash    string
	Content string
}
